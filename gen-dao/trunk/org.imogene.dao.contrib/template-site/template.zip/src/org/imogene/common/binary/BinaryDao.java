package org.imogene.common.binary;

import org.imogene.common.dao.ImogBeanDao;

/**
 * Manage persistence for Binary
 * 
 * @author MEDES-IMPS
 */
public interface BinaryDao<T extends Binary> extends ImogBeanDao<T> {

}
