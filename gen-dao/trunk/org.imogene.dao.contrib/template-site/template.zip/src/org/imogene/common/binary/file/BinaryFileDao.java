package org.imogene.common.binary.file;

import org.imogene.common.binary.BinaryDao;

public interface BinaryFileDao extends BinaryDao<BinaryFile> {

}
