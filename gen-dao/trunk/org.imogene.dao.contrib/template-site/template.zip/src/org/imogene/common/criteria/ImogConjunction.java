package org.imogene.common.criteria;

public class ImogConjunction extends ImogJunction {

	public static String TYPE = "Conjunction";

	@Override
	public String getType() {
		return TYPE;
	}

}
