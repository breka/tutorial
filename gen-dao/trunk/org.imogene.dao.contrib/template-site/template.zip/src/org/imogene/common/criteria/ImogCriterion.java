package org.imogene.common.criteria;

import java.io.Serializable;

public interface ImogCriterion extends Serializable {
}
