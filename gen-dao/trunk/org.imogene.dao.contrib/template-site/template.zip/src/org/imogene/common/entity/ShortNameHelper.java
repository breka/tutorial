package org.imogene.common.entity;

public interface ShortNameHelper {

	public String getClassName(String shortName);

	public String getShortName(String className);
}