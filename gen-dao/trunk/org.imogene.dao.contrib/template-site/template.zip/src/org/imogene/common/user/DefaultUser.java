package org.imogene.common.user;

import javax.persistence.Entity;

import org.imogene.common.entity.ImogActorImpl;

@Entity
public class DefaultUser extends ImogActorImpl {

}