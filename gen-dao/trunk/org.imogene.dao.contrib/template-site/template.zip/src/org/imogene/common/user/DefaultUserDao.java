package org.imogene.common.user;

import org.imogene.common.dao.ImogActorDao;

public interface DefaultUserDao extends ImogActorDao<DefaultUser> {

}
