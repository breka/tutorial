package org.imogene.android.preference;

public interface MyPreference {
	
	public void onAttachToHierarchy(MyPreferenceManager manager);

}
