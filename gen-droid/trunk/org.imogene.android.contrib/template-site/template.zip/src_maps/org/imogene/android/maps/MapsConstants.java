package org.imogene.android.maps;

public final class MapsConstants {
	
	public static final int DEFAULT_LATIUDE_E6 = 43604472;
	public static final int DEFAULT_LONGITUDE_E6 = 1442975;
	public static final int DEFAULT_NORTH_E6 = 44119142;
	public static final int DEFAULT_WEST_E6 = 593262;
	public static final int DEFAULT_SOUTH_E6 = 42488302;
	public static final int DEFAULT_EAST_E6 = 2922363;
	
	public static final double DEFAULT_LATIUDE = DEFAULT_LATIUDE_E6 / 1E6;
	public static final double DEFAULT_LONGITUDE = DEFAULT_LONGITUDE_E6 / 1E6;
	public static final double DEFAULT_NORTH = DEFAULT_NORTH_E6 / 1E6;
	public static final double DEFAULT_WEST = DEFAULT_WEST_E6 / 1E6;
	public static final double DEFAULT_SOUTH = DEFAULT_SOUTH_E6 / 1E6;
	public static final double DEFAULT_EAST = DEFAULT_EAST_E6 / 1E6;
	
	public static final String EXTRA_LOCATION = "location";

	public static final String EXTRA_LATITUDE = "latitude";

	public static final String EXTRA_LONGITUDE = "longitude";
	
}
