package org.imogene.android.maps;

import org.imogene.android.R;
import org.osmdroid.ResourceProxy;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;

public class ResourceProxyImpl implements ResourceProxy {
	
	private final Resources mResources;
	
	public ResourceProxyImpl(Context context) {
		mResources = context.getResources();
	}
	
	@Override
	public Bitmap getBitmap(bitmap resId) {
		switch (resId) {
		case center:
			return BitmapFactory.decodeResource(mResources, R.drawable.center);
		case direction_arrow:
			return BitmapFactory.decodeResource(mResources, R.drawable.direction_arrow);
		case ic_menu_compass:
			return BitmapFactory.decodeResource(mResources, R.drawable.ic_menu_compass);
		case ic_menu_mapmode:
			return BitmapFactory.decodeResource(mResources, R.drawable.ic_menu_mapmode);
		case ic_menu_mylocation:
			return BitmapFactory.decodeResource(mResources, R.drawable.ic_menu_mylocation);
		case ic_menu_offline:
			return BitmapFactory.decodeResource(mResources, R.drawable.ic_menu_offline);
		case marker_default:
			return BitmapFactory.decodeResource(mResources, R.drawable.marker_default);
		case marker_default_focused_base:
			return BitmapFactory.decodeResource(mResources, R.drawable.marker_default_focused_base);
		case navto_small:
			return BitmapFactory.decodeResource(mResources, R.drawable.navto_small);
		case next:
			return BitmapFactory.decodeResource(mResources, R.drawable.next);
		case person:
			return BitmapFactory.decodeResource(mResources, R.drawable.person);
		case previous:
			return BitmapFactory.decodeResource(mResources, R.drawable.previous);
		case unknown:
			return BitmapFactory.decodeResource(mResources, R.drawable.center);
		default:
			return null;
		}
	}
	
	@Override
	public float getDisplayMetricsDensity() {
		return mResources.getDisplayMetrics().density;
	}
	
	@Override
	public Drawable getDrawable(bitmap resId) {
		switch (resId) {
		case center:
			return mResources.getDrawable(R.drawable.center);
		case direction_arrow:
			return mResources.getDrawable(R.drawable.direction_arrow);
		case ic_menu_compass:
			return mResources.getDrawable(R.drawable.ic_menu_compass);
		case ic_menu_mapmode:
			return mResources.getDrawable(R.drawable.ic_menu_mapmode);
		case ic_menu_mylocation:
			return mResources.getDrawable(R.drawable.ic_menu_mylocation);
		case ic_menu_offline:
			return mResources.getDrawable(R.drawable.ic_menu_offline);
		case marker_default:
			return mResources.getDrawable(R.drawable.marker_default);
		case marker_default_focused_base:
			return mResources.getDrawable(R.drawable.marker_default_focused_base);
		case navto_small:
			return mResources.getDrawable(R.drawable.navto_small);
		case next:
			return mResources.getDrawable(R.drawable.next);
		case person:
			return mResources.getDrawable(R.drawable.person);
		case previous:
			return mResources.getDrawable(R.drawable.previous);
		case unknown:
			return mResources.getDrawable(R.drawable.center);
		default:
			return null;
		}
	}
	
	public String getString(string resId) {
		switch (resId) {
		case base:
			return mResources.getString(R.string.base);
		case base_nl:
			return mResources.getString(R.string.base_nl);
		case bing:
			return mResources.getString(R.string.bing);
		case cloudmade_small:
			return mResources.getString(R.string.cloudmade_small);
		case cloudmade_standard:
			return mResources.getString(R.string.cloudmade_standard);
		case compass:
			return mResources.getString(R.string.compass);
		case cyclemap:
			return mResources.getString(R.string.cyclemap);
		case fiets_nl:
			return mResources.getString(R.string.fiets_nl);
		case format_distance_feet:
			return mResources.getString(R.string.format_distance_feet);
		case format_distance_kilometers:
			return mResources.getString(R.string.format_distance_kilometers);
		case format_distance_meters:
			return mResources.getString(R.string.format_distance_meters);
		case format_distance_miles:
			return mResources.getString(R.string.format_distance_miles);
		case format_distance_nautical_miles:
			return mResources.getString(R.string.format_distance_nautical_miles);
		case hills:
			return mResources.getString(R.string.hills);
		case map_mode:
			return mResources.getString(R.string.map_mode);
		case mapnik:
			return mResources.getString(R.string.mapnik);
		case mapquest_aerial:
			return mResources.getString(R.string.mapquest_aerial);
		case mapquest_osm:
			return mResources.getString(R.string.mapquest_osm);
		case my_location:
			return mResources.getString(R.string.my_location);
		case offline_mode:
			return mResources.getString(R.string.offline_mode);
		case online_mode:
			return mResources.getString(R.string.online_mode);
		case osmarender:
			return mResources.getString(R.string.osmarender);
		case public_transport:
			return mResources.getString(R.string.public_transport);
		case roads_nl:
			return mResources.getString(R.string.roads_nl);
		case topo:
			return mResources.getString(R.string.topo);
		case unknown:
			return mResources.getString(R.string.unknown);
		default:
			return null;
		}
	};
	
	@Override
	public String getString(string resId, Object... formatArgs) {
		switch (resId) {
		case base:
			return mResources.getString(R.string.base, formatArgs);
		case base_nl:
			return mResources.getString(R.string.base_nl, formatArgs);
		case bing:
			return mResources.getString(R.string.bing, formatArgs);
		case cloudmade_small:
			return mResources.getString(R.string.cloudmade_small, formatArgs);
		case cloudmade_standard:
			return mResources.getString(R.string.cloudmade_standard, formatArgs);
		case compass:
			return mResources.getString(R.string.compass, formatArgs);
		case cyclemap:
			return mResources.getString(R.string.cyclemap, formatArgs);
		case fiets_nl:
			return mResources.getString(R.string.fiets_nl, formatArgs);
		case format_distance_feet:
			return mResources.getString(R.string.format_distance_feet, formatArgs);
		case format_distance_kilometers:
			return mResources.getString(R.string.format_distance_kilometers, formatArgs);
		case format_distance_meters:
			return mResources.getString(R.string.format_distance_meters, formatArgs);
		case format_distance_miles:
			return mResources.getString(R.string.format_distance_miles, formatArgs);
		case format_distance_nautical_miles:
			return mResources.getString(R.string.format_distance_nautical_miles, formatArgs);
		case hills:
			return mResources.getString(R.string.hills, formatArgs);
		case map_mode:
			return mResources.getString(R.string.map_mode, formatArgs);
		case mapnik:
			return mResources.getString(R.string.mapnik, formatArgs);
		case mapquest_aerial:
			return mResources.getString(R.string.mapquest_aerial, formatArgs);
		case mapquest_osm:
			return mResources.getString(R.string.mapquest_osm, formatArgs);
		case my_location:
			return mResources.getString(R.string.my_location, formatArgs);
		case offline_mode:
			return mResources.getString(R.string.offline_mode, formatArgs);
		case online_mode:
			return mResources.getString(R.string.online_mode, formatArgs);
		case osmarender:
			return mResources.getString(R.string.osmarender, formatArgs);
		case public_transport:
			return mResources.getString(R.string.public_transport, formatArgs);
		case roads_nl:
			return mResources.getString(R.string.roads_nl, formatArgs);
		case topo:
			return mResources.getString(R.string.topo, formatArgs);
		case unknown:
			return mResources.getString(R.string.unknown, formatArgs);
		default:
			return null;
		}
	}

}
