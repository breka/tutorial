package org.imogene.android.maps.app;

import greendroid.app.GDApplication;
import android.content.Intent;
import android.net.Uri;

public class MapApplication extends GDApplication {

    @Override
    public Class<?> getHomeActivityClass() {
        return Integer.class;
    }
    
    @Override
    public Intent getMainApplicationIntent() {
        return new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
    }

}
