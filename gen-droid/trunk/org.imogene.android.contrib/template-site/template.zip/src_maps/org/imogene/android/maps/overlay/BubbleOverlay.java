package org.imogene.android.maps.overlay;

import org.imogene.android.R;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.View;

public class BubbleOverlay extends Overlay {

	private final Bitmap bubbleIcon;
	private final Bitmap shadowIcon;
	
	private final Point reuse = new Point();
	
	private View mParent;

	private IGeoPoint mGeoPoint;
	
	public BubbleOverlay(Context context, GeoPoint point) {
		super(context);
		mGeoPoint = point;

		bubbleIcon = BitmapFactory.decodeResource(context.getResources(), R.drawable.bubble);
		shadowIcon = BitmapFactory.decodeResource(context.getResources(), R.drawable.shadow);
	}
	
	public IGeoPoint getGeoPoint() {
		return mGeoPoint;
	}
	
	public void setGeoPoint(IGeoPoint point) {
		mGeoPoint = point;
		refreshOverlay();
	}
	
	public void refreshOverlay() {
		if (mParent != null) {
			mParent.postInvalidate();
		}
	}
	
	void assignParent(View parent) {
		if (mParent != parent) {
			mParent = parent;
		}
	}

	@Override
	protected void draw(Canvas canvas, MapView mapView, boolean shadow) {
		assignParent(mapView);
   		drawMapLocations(canvas, mapView);
	}

    private void drawMapLocations(Canvas canvas, MapView mapView) {
		mapView.getProjection().toMapPixels(mGeoPoint, reuse);
		
		canvas.drawBitmap(bubbleIcon, reuse.x - bubbleIcon.getWidth()/2 , reuse.y - bubbleIcon.getHeight(),null);
    	canvas.drawBitmap(shadowIcon, reuse.x - 1, reuse.y - shadowIcon.getHeight(),null);
    }
    
	protected final boolean overlayIsSelected(int x, int y) {
		// Track which MapLocation was hit...if any
		RectF hitTestRecr = new RectF();

		// Create a 'hit' testing Rectangle w/size and coordinates of our icon
		// Set the 'hit' testing Rectangle with the size and coordinates of our on screen icon
		hitTestRecr.set(-bubbleIcon.getWidth() / 2,	-bubbleIcon.getHeight(), bubbleIcon.getWidth() / 2, 0);
		hitTestRecr.offset(reuse.x, reuse.y);

		// Finally test for a match between our 'hit' Rectangle and the
		// location clicked by the user
		return hitTestRecr.contains(x, y);
	}
	
	protected Point getMarkerPoint() {
		return reuse;
	}
	
}
