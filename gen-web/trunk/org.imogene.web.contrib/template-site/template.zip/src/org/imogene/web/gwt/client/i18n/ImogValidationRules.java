

package org.imogene.web.gwt.client.i18n;

import com.google.gwt.i18n.client.Constants;

public interface ImogValidationRules extends Constants {

	/* Languages texts */
		
}
