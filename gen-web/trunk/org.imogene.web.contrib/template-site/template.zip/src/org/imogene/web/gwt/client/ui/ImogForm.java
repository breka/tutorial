package org.imogene.web.gwt.client.ui;

public interface ImogForm {

	public boolean isDirty();
	
	public boolean isEditable();
	
}
