package org.imogene.web.gwt.client.ui.field;

import org.imogene.web.gwt.common.entity.ImogBean;

public interface MainFieldsUtil {

	public String getDisplayValue(ImogBean bean);
	
	public String getIconUrl(ImogBean bean);
}
