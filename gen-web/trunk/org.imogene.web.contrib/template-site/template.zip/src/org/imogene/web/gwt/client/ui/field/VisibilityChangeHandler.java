package org.imogene.web.gwt.client.ui.field;

public interface VisibilityChangeHandler {

	public void onVisibilityChange(boolean visibility, ImogField<?> field);
}
