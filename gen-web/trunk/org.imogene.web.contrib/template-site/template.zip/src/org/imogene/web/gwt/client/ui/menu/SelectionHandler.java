package org.imogene.web.gwt.client.ui.menu;

public interface SelectionHandler {
	
	public void selectionEvent(MenuItem item);
}
