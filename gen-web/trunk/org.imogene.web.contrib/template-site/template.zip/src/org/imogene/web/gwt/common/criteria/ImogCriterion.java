package org.imogene.web.gwt.common.criteria;

import com.google.gwt.user.client.rpc.IsSerializable;

public interface ImogCriterion extends IsSerializable {	
}
