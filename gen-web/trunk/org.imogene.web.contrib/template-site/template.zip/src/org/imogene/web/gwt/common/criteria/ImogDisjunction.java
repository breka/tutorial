package org.imogene.web.gwt.common.criteria;


public class ImogDisjunction extends ImogJunction {

	public static String TYPE = "Disjunction";
	
	@Override
	public String getType() {		
		return TYPE;
	}
		
		
}
