package org.imogene.ws.criteria;

public class MedooConjunction extends MedooJunction {

	public static String TYPE = "Conjunction";
	
	public String getType(){
		return TYPE;
	}
	
}
