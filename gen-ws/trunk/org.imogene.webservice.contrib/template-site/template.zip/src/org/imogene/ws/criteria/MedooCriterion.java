package org.imogene.ws.criteria;


public interface MedooCriterion {	
}
