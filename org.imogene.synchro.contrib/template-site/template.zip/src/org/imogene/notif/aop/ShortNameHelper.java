package org.imogene.notif.aop;

public interface ShortNameHelper {

	public String getClassName(String shortName);
	
	public String getShortName(String className);
}
