/** Automatically generated file. DO NOT MODIFY */
package org.imogene.android.template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}