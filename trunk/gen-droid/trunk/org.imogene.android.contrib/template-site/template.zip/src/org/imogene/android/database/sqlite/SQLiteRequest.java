package org.imogene.android.database.sqlite;

public interface SQLiteRequest {
	
	public String toSQL();

}
