package org.imogene.android.maps.app;

import greendroid.app.GDActivity;
import greendroid.widget.ActionBar;

import org.imogene.android.maps.ResourceProxyImpl;
import org.imogene.android.template.R;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.util.CloudmadeUtil;
import org.osmdroid.views.MapView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

public class MapActivity extends GDActivity {
	
	private static final String PREFERENCES_NAME = "name";
	private static final String PREFERENCE_ZOOM_LEVEL = "zoomLevel";
	private static final String PREFERENCE_SCROLL_X = "scrollX";
	private static final String PREFERENCE_SCROLL_Y = "scrollY";
	private static final String PREFERENCE_TILE_SOURCE = "tileSource";
	
	private static final int MENU_MAP_MODE_ID = 2;
	private static final int MENU_OFFLINE_ID = 3;

	private MapView mMapView;
	private ResourceProxy mResourceProxy;
	
	private SharedPreferences mPrefs;
	
	public MapActivity() {
		super(ActionBar.Type.Empty);
	}
	
	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// only do static initialisation if needed
		if (CloudmadeUtil.getCloudmadeKey().length() == 0) {
			CloudmadeUtil.retrieveCloudmadeKey(getApplicationContext());
		}
		
		mPrefs = getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);

		mResourceProxy = new ResourceProxyImpl(this);
		
		mMapView = new MapView(this, 256, mResourceProxy);
		mMapView.setBuiltInZoomControls(true);
		mMapView.setMultiTouchControls(true);
		setActionBarContentView(
				mMapView, 
				new RelativeLayout.LayoutParams(
						LayoutParams.FILL_PARENT,
						LayoutParams.FILL_PARENT));
		
		mMapView.getController().setZoom(mPrefs.getInt(PREFERENCE_ZOOM_LEVEL, 1));
		mMapView.scrollTo(mPrefs.getInt(PREFERENCE_SCROLL_X, 0), mPrefs.getInt(PREFERENCE_SCROLL_Y, 0));
	}
	
	public MapView getMapView() {
		return mMapView;
	}
	
	public ResourceProxy getResourceProxy() {
		return mResourceProxy;
	}
	
	public void autozoom(IGeoPoint point) {
		mMapView.getController().animateTo(point);
	}
	
	@Override
	protected void onPause() {
		final SharedPreferences.Editor edit = mPrefs.edit();
		edit.putString(PREFERENCE_TILE_SOURCE, mMapView.getTileProvider().getTileSource().name());
		edit.putInt(PREFERENCE_SCROLL_X, mMapView.getScrollX());
		edit.putInt(PREFERENCE_SCROLL_Y, mMapView.getScrollY());
		edit.putInt(PREFERENCE_ZOOM_LEVEL, mMapView.getZoomLevel());
		edit.commit();

		super.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		final String tileSourceName = mPrefs.getString(PREFERENCE_TILE_SOURCE,
				TileSourceFactory.DEFAULT_TILE_SOURCE.name());
		try {
			final ITileSource tileSource = TileSourceFactory.getTileSource(tileSourceName);
			mMapView.setTileSource(tileSource);
		} catch (final IllegalArgumentException ignore) {
		}
	}

	@Override
	public boolean onTrackballEvent(final MotionEvent event) {
		return mMapView.onTrackballEvent(event);
	}
	
	@Override
	public boolean onCreateOptionsMenu(final Menu menu) {
		SubMenu mapMenu = menu.addSubMenu(0, MENU_MAP_MODE_ID, Menu.NONE, R.string.ig_map_mode).setIcon(R.drawable.ic_menu_mapmode);
		
		for (int a = 0; a < TileSourceFactory.getTileSources().size(); a++) {
			final ITileSource tileSource = TileSourceFactory.getTileSources().get(a);
			mapMenu.add(MENU_MAP_MODE_ID, 1000 + tileSource.ordinal(), Menu.NONE, tileSource.localizedName(mResourceProxy));
		}
		mapMenu.setGroupCheckable(MENU_MAP_MODE_ID, true, true);
		
		menu.add(MENU_OFFLINE_ID, MENU_OFFLINE_ID, Menu.NONE, R.string.ig_offline_mode).setIcon(R.drawable.ic_menu_offline);
		return true;
	}
	
	@Override
	public boolean onPrepareOptionsMenu(final Menu menu) {
		final int ordinal = mMapView.getTileProvider().getTileSource().ordinal();
    	menu.findItem(1000 + ordinal).setChecked(true);
		menu.findItem(MENU_OFFLINE_ID).setTitle(mMapView.useDataConnection() ? R.string.ig_offline_mode : R.string.ig_online_mode);
		return true;
	}
	
	@Override
	public boolean onMenuItemSelected(final int featureId, final MenuItem item) {
		switch (item.getGroupId()) {
		case MENU_MAP_MODE_ID:
			mMapView.setTileSource(TileSourceFactory.getTileSources().get(item.getItemId() - 1000));
			return true;
		case MENU_OFFLINE_ID:
			final boolean useDataConnection = !mMapView.useDataConnection();
			mMapView.setUseDataConnection(useDataConnection);
			final int id = useDataConnection ? R.string.ig_set_mode_online : R.string.ig_set_mode_offline;
			Toast.makeText(this, id, Toast.LENGTH_LONG).show();
			return true;
		default:
			return super.onMenuItemSelected(featureId, item);
		}
	}
	
}
