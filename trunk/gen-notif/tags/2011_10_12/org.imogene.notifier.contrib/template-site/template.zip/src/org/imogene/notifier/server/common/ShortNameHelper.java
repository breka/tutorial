package org.imogene.notifier.server.common;

public interface ShortNameHelper {

	public String getClassName(String shortName);
	
	public String getShortName(String className);
}
