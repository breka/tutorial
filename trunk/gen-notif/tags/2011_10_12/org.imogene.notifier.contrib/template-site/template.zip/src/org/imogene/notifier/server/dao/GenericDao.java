package org.imogene.notifier.server.dao;

public interface GenericDao {

	public Object load(Class<?> clazz, String id);
}
