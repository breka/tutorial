package org.imogene.notif.web.gwt.client;

import com.google.gwt.core.client.EntryPoint;

public class ImogNotifEntryPoint implements EntryPoint {

	@Override
	public void onModuleLoad() {
	
	}
	
}
