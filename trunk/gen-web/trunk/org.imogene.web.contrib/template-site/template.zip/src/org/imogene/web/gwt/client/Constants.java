package org.imogene.web.gwt.client;

public final class Constants {
	
	/* URL */
	public static String RPC_URL_BASE = "/../../";
}
