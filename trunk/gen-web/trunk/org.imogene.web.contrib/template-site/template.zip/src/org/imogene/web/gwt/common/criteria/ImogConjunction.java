package org.imogene.web.gwt.common.criteria;

public class ImogConjunction extends ImogJunction {

	public static String TYPE = "Conjunction";
	
	public String getType(){
		return TYPE;
	}
	
}
