package org.imogene.web.gwt.common.entity;

public final class CommonConstants {
	
	/* Constant that identifies a web application of an imogene information system */
	public static String IS_WEB = "web";
}
