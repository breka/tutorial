package org.imogene.ws.criteria;


public class MedooDisjunction extends MedooJunction {

	public static String TYPE = "Disjunction";
	
	@Override
	public String getType() {		
		return TYPE;
	}
		
		
}
